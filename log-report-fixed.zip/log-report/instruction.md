Parse the Apache-style access log located at `/app/access.log` and write a JSON report to `/app/report.json`.

The report must be a JSON object.

Success criteria:

1. Write the report to exactly `/app/report.json`.
2. Include an integer field `total_requests`.
3. Include an integer field `unique_ips`.
4. Include a string field `top_path`.
